from Spatial import *
from Time import *
from Metaculus import *
print(fromState2FIPS("DC"))
for i in range(0,7):
    print(getClosestDay(i))
# print(fromDate2Epiweek("2021-01-03"))
# print(fromDates2Epiweeks(["2021-01-03","2021-02-04","2021-03-05"]))
# print(todayEpiWeek())


